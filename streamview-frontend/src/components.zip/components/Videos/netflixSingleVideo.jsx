import React from "react";
import Helper from "../../Helper/helper";

class netflixSingleVideo extends Helper {
  render() {
    return <div>Hello</div>;
  }
}
export default netflixSingleVideo;
