import React from 'react';

const SliderContext = React.createContext();

export default SliderContext;
