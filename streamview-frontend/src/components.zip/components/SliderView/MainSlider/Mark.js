import React from "react";
import "./Mark.scss";

const Mark = () => <div className="markcontent" />;

export default Mark;
