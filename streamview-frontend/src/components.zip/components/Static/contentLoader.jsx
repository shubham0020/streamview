import React from "react";
import { Facebook } from "react-content-loader";

const ContentLoader = () => {
  return <Facebook speed={2} />;
};

export default ContentLoader;
